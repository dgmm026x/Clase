/////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////



interface IJugadorDAO {
	
	public static void borrarJugador(Jugador jugador) {}
	
	public static void crearJugador(Jugador jugador) {}
	
	public static void existeJugadorPorNombre(Jugador jugador) {}
	
	public static void existeJugadorPorId(int id) {}
	
	public static void listaJugadores() {}
	
	public static void cerrarConexion() {}
}



/////////////////////////////////////////////////////////////////