/////////////////////////////////////////////////////////////////



/////////////////////////////////////////////////////////////////



class Jugador {
	
	private int id;
	private String nombre;
	
	
	
	Jugador() {}
	
	
	
	public void setId(int nuevoId) {
		
		this.id = nuevoId;
	}
	
	public int getId() {
		
		return id;
	}
	
	public void setNombre(String nuevoNombre) {
		
		this.nombre = nuevoNombre;
	}
	
	public String getNombre() {
		
		return nombre;
	}
}



/////////////////////////////////////////////////////////////////