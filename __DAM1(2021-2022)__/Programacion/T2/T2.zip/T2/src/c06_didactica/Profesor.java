package c06_didactica;

class Profesor
{
	
}