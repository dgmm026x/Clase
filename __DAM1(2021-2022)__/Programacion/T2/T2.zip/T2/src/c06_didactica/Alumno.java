package c06_didactica;

public class Alumno
{
	public String Nombre;
	private double Nota;
	String Direccion;
}