package c12_polimorfismo;

class profesor extends persona
{
	String queSoy;
	
	@Override
	String queSoy()
	{
		return queSoy="profesor";
	}
}