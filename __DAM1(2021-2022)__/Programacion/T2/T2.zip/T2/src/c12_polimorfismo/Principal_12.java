package c12_polimorfismo;

public class Principal_12
{
	public static void main(String[] args)
	{
		persona p=new persona();
		System.out.println(p.queSoy());
		p=new alumno();
		System.out.println(p.queSoy());
	}
}