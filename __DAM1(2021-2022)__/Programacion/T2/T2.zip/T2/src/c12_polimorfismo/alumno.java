package c12_polimorfismo;

class alumno extends persona
{
	String queSoy;
	
	@Override
	String queSoy()
	{
		return queSoy="alumno";
	}
}