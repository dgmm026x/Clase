package c12_polimorfismo;

abstract class persona
{
	String queSoy;
	
	String queSoy()
	{
		return null;
	}
}