//////////////////////////////////////////////////////////////////


package c16_Impresora;


//////////////////////////////////////////////////////////////////


class Forma
{
	protected char Color;
	protected double[] Centro;
	protected String NombreForma;
	
	Forma(char Color, double CoordenadaX, double CoordenadaY, String NombreForma)
	{
		this.Color=Color;
		Centro[0]=CoordenadaX;
		Centro[1]=CoordenadaY;
	}
}


//////////////////////////////////////////////////////////////////