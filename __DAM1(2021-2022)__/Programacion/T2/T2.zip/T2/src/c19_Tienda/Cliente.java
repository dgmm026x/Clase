////////////////////////////////////////////////////////////////


package c19_Tienda;


////////////////////////////////////////////////////////////////


class Cliente
{
	protected String Nombre;
	protected String Apellido1;
	protected String Apellido2;
	protected String Genero;
	protected int Edad;
	protected double Gastos;
	
	
	Cliente(String Nombre,String Apellido1,String Apellido2,String Genero,int Edad,double Gastos)
	{
		this.Nombre=Nombre;
		this.Apellido1=Apellido1;
		this.Apellido2=Apellido2;
		this.Genero=Genero;
		this.Edad=Edad;
		this.Gastos=Gastos;
	}
	
	String Descripcion()
	{
		return "Cliente: "+Nombre+" "+Apellido1+" "+Apellido2+", edad:"+Edad+", g�nero "+Genero+", gastos:"+Gastos+"�";
	}
}


////////////////////////////////////////////////////////////////