////////////////////////////////////////////////////////////////


package c19_Tienda;


////////////////////////////////////////////////////////////////


public class MAIN
{
	public static void main(String[] args)
	{
		Tienda T1=new Tienda();
		
		T1.NuevoCliente("Nicol","Unu","�o","desconocido",0,696);
		T1.NuevoCliente("Nicol","Unu","�o","desconocido",0,696);
		T1.NuevoCliente("Nicol","Unu","�o","desconocido",0,696);
		T1.NuevoCliente("Nicol","Unu","�o","desconocido",0,696);
		
		
		System.out.println(T1.DatosVentas());
	}
}


////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////