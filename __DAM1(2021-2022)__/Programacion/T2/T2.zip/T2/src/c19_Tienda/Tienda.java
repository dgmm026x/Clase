////////////////////////////////////////////////////////////////


package c19_Tienda;
import java.util.Arrays;


////////////////////////////////////////////////////////////////


public class Tienda
{
	private int Longitud;
	private int Posicion;
	protected Cliente Datos[];
	
	
	Tienda()
	{
		this.Longitud=3;
		this.Posicion=0;
		this.Datos=new Cliente[Longitud];
	}
	
	
	void NuevoCliente(String Nombre,String Apellido1,String Apellido2,String Genero,int Edad,double Gastos)
	{
		if(Posicion==Longitud)
		{
			Longitud+=Longitud;
			Datos=Arrays.copyOf(Datos,Longitud);
		}
		
		
		Cliente c1=new Cliente(Nombre,Apellido1,Apellido2,Genero,Edad,Gastos);
		this.Datos[Posicion]=c1;
		Posicion++;
	}
	
	
	String DatosVentas()
	{
		//System.out.println(Arrays.toString(this.Datos));
		//System.out.println(Posicion);
		//System.out.println(Longitud);
		String Ventas="";
		for(int i=0;i<Posicion;i++)
		{
			Ventas+="  Venta n."+(i+1)+": "+Datos[i].Descripcion()+"\n";
			
		}
		return Ventas;
	}
}


////////////////////////////////////////////////////////////////