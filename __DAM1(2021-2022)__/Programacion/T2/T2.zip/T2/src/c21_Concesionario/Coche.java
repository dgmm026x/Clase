/////////////////////////////////////////////////////////////////


package c21_Concesionario;


/////////////////////////////////////////////////////////////////


class Coche extends Vehiculo
{
	protected double Potencia;
	
	
	Coche(TipoVehiculo Tipo,String Color,String Matricula,double Potencia)
	{
		super(Tipo,Color,Matricula);
		setPotencia(Potencia);
	}
	
	
	protected void setPotencia(double Potencia){this.Potencia=Potencia;}
	protected double gePotencia(){return Potencia;}
	
	
	@Override
	protected String MostrarVehiculo()
	{
		return " Coche --> Tipo: "+Tipo+", Color: "+Color+", Matricula: "+Matricula+", Potencia: "+Potencia;
	}
}


/////////////////////////////////////////////////////////////////