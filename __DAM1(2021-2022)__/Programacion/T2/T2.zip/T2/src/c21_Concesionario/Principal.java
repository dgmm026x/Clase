package c21_Concesionario;

class Principal {

	protected static void main(String[] args) {
		// TODO Auto-generated method stub

		Concesionario CONCESIONARIO_1=new Concesionario();
		
		CONCESIONARIO_1.AltaCoche(TipoVehiculo.NORMAL,"Negro","5232SDG",230);
		
		System.out.println(CONCESIONARIO_1.MostrarListaVehiculos());
	}

}
