/////////////////////////////////////////////////////////////////


package c21_Concesionario;


/////////////////////////////////////////////////////////////////


class Furgoneta extends Vehiculo
{
	protected double Tara;
	
	
	Furgoneta(TipoVehiculo Tipo,String Color,String Matricula,double Tara)
	{
		super(Tipo,Color,Matricula);
		this.Tara=Tara;
	}
	
	
	protected void setTara(double Tara){this.Tara=Tara;}
	protected double getTara(){return Tara;}
}


/////////////////////////////////////////////////////////////////