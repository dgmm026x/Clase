/////////////////////////////////////////////////////////////////


package c21_Concesionario;


/////////////////////////////////////////////////////////////////


class Vehiculo
{
	protected TipoVehiculo Tipo;
	protected String Color;
	protected String Matricula;
	//protected int ID;
	
	
	Vehiculo(TipoVehiculo Tipo,String Color,String Matricula)
	{
		super();
		setTipoVehiculo(Tipo);
		setColor(Color);
		setMatricula(Matricula);
		//setID(ID);
		/*this.Tipo=Tipo;
		this.TipoVehiculo=TipoVehiculo;
		this.Color=Color;
		this.Matricula=Matricula;*/
	}
	
	
	protected void setTipoVehiculo(TipoVehiculo Tipo){}
	protected TipoVehiculo getTipoVehiculo(){return Tipo;}
	
	
	protected void setColor(String Color){this.Color=Color;}
	protected String getColor(){return Color;}
	
	
	protected void setMatricula(String Matricula){this.Matricula=Matricula;}
	protected String getMatricula(){return Matricula;}
	
	
	/*protected void setID(int ID){this.ID=ID;}
	protected int getID(){return ID;}*/
	
	
	protected String MostrarVehiculo(){return "";}
}


/////////////////////////////////////////////////////////////////