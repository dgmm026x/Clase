/////////////////////////////////////////////////////////////////


package c21_Concesionario;


/////////////////////////////////////////////////////////////////


class Concesionario
{
	protected Vehiculo[] ListaVehiculos;
	protected int ListaLongitud;
	protected int ListaPosicion;
	//protected int ID;
	
	
	Concesionario()
	{
		this.ListaLongitud=50;
		this.ListaPosicion=0;
		this.ListaVehiculos=new Vehiculo[ListaLongitud];
		//this.ID=0;
	}
	
	
	protected void AltaCoche(TipoVehiculo Tipo,String Color,String Matricula,double Potencia)
	{
		//ID++;
		Vehiculo COCHE=new Coche(Tipo,Color,Matricula,Potencia);
		ListaVehiculos[ListaPosicion]=COCHE;
		ListaPosicion++;
	}
	
	
	protected void AltaFurgoneta(TipoVehiculo Tipo,String Color,String Matricula,double Tara)
	{
		//ID++;
		Vehiculo FURGONETA=new Furgoneta(Tipo,Color,Matricula,Tara);
		ListaVehiculos[ListaPosicion]=FURGONETA;
		ListaPosicion++;
	}
	
	
	protected String MostrarListaVehiculos()
	{
		String Lista="";
		for (int i=0;i<ListaPosicion;i++)
		{
			Lista+="Vehiculo "+ListaVehiculos[i].MostrarVehiculo()+"\n";
		}
		return Lista;
	}
}


/////////////////////////////////////////////////////////////////