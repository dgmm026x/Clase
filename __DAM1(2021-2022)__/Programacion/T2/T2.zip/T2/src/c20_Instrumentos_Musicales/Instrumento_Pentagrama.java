////////////////////////////////////////////////////////////////


package c20_Instrumentos_Musicales;


////////////////////////////////////////////////////////////////


class Instrumento_Pentagrama
{
	protected AlturaNota PENTAGRAMA[];
	private int LONG;
	protected int POSICION;
	
	
	Instrumento_Pentagrama()
	{
		this.LONG=100;
		this.POSICION=0;
		this.PENTAGRAMA=new AlturaNota[LONG];
	}
	
	
	protected String darNombre()
	{
		return "Predeterminado";
	}
	
	
	protected void NuevaNota(AlturaNota Altura)
	{
		if(POSICION==99)
		{
			System.out.println(" ---L�mite del pentagrama alcanzado---");
		}
		else
		{
			PENTAGRAMA[POSICION]=Altura;
			POSICION++;
		}
	}
	
	
	protected void EliminarNota(AlturaNota Altura)
	{
		PENTAGRAMA[POSICION]=null;
		POSICION--;
	}
	
	
	protected String LeerNotas()
	{
		System.out.println();
		String Notas="  Notas: ";
		for (int i=0;i<POSICION;i++)
		{
			Notas+=PENTAGRAMA[i]+" ";
		}
		return Notas;
	}
	
	
	protected void MostrarPentagrama()
	{
		System.out.println();
		System.out.println();
		System.out.println("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /");
		System.out.println();
		System.out.println();
		System.out.println(" � PARTITURA:");
		System.out.println();
		System.out.println();
		
		//	SIs
		System.out.print(" +SI  �            ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.SIs)
			{
				System.out.print(" o ");
			}
			else
			{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	LAs
		System.out.print(" +LA  �            ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.LAs)
			{
				System.out.print("-o-");
			}
			else
			{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
			
		
		//	SOLs
		System.out.print(" +SOL �            ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.SOLs)
			{
				System.out.print(" o ");
			}
			else
			{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	FAs
		System.out.print(" +FA  � ---@-------");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.FAs)
			{
				System.out.print("-o-");
			}
			else
			{
				System.out.print("---");
			}
		}
		System.out.print("----------- �\n");
		
		
		//	MIs
		System.out.print(" +MI  �   /|       ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.MIs)
			{
				System.out.print(" o ");
			}
			else
			{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	REs
		System.out.print(" +RE  � --||-------");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.REs)
			{
				System.out.print("-o-");
			}
			else
			{
				System.out.print("---");
			}
		}
		System.out.print("----------- �\n");
		
		
		//	DOs
		System.out.print(" +DO  �   ||       ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.DOs)
			{
				System.out.print(" o ");
			}
			else
			{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	SI
		System.out.print("  SI  � --||-------");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.SI)
			{
				System.out.print("-o-");
			}
			else
			{
				System.out.print("---");
			}
		}
		System.out.print("----------- �\n");
		
		
		//	LA
		System.out.print("  LA  �  /@@L      ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.LA)
			{
				System.out.print(" o ");
			}
			else
				{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	SOL
		System.out.print("  SOL � -|@@S|_/---");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.SOL)
			{
				System.out.print("-o-");
			}
			else
			{
				System.out.print("---");
			}
		}
		System.out.print("----------- �\n");
		
		
		//	FA
		System.out.print("  FA  �  L@@/      ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.FA)
			{
				System.out.print(" o ");
			}
			else
				{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	MI
		System.out.print("  MI  � ---|-------");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.MI)
			{
				System.out.print("-o-");
			}
			else
			{
				System.out.print("---");
			}
		}
		System.out.print("----------- �\n");
		
		
		//	RE
		System.out.print("  RE  �   @|       ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.RE)
			{
				System.out.print(" o ");
			}
			else
				{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		
		
		//	DO
		System.out.print("  DO  �            ");
		for (int i=0;i<POSICION;i++)
		{
			if(PENTAGRAMA[i]==AlturaNota.DO)
			{
				System.out.print("-o-");
			}
			else
				{
				System.out.print("   ");
			}
		}
		System.out.print("            �\n");
		System.out.println();
		System.out.println();
		System.out.println("/ / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / / /");
		System.out.println();
		System.out.println();
		
	}
}


////////////////////////////////////////////////////////////////