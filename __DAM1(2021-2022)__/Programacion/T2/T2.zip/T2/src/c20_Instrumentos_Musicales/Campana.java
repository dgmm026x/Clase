////////////////////////////////////////////////////////////////


package c20_Instrumentos_Musicales;


////////////////////////////////////////////////////////////////


class Campana extends Instrumento_Pentagrama
{
	@Override
	protected String darNombre()
	{
		return "Campana";
	}
	
	
	@Override
	protected String LeerNotas()
	{
		String Notas=" � INTERPRETACION: ";
		for(int i=0;i<POSICION;i++)
		{
			switch(PENTAGRAMA[i])
			{
				case DO:
					Notas+="DOOoo. ";
					break;
				case RE:
					Notas+="REEee. ";
					break;
				case MI:
					Notas+="MIIii. ";
					break;
				case FA:
					Notas+="FAAaa. ";
					break;
				case SOL:
					Notas+="SOOol. ";
					break;
				case LA:
					Notas+="LAAaa. ";
					break;
				case SI:
					Notas+="SIIii. ";
					break;
				case DOs:
					Notas+="+DOOoo. ";
					break;
				case REs:
					Notas+="+REEee. ";
					break;
				case MIs:
					Notas+="+MIIii. ";
					break;
				case FAs:
					Notas+="+FAAaa. ";
					break;
				case SOLs:
					Notas+="+SOOol. ";
					break;
				case LAs:
					Notas+="+LAAaa. ";
					break;
				case SIs:
					Notas+="+SIIii. ";
					break;
			}
		}
		return Notas;
	}
}


////////////////////////////////////////////////////////////////