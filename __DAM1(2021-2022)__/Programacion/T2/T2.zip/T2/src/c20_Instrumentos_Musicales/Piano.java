////////////////////////////////////////////////////////////////


package c20_Instrumentos_Musicales;


////////////////////////////////////////////////////////////////


class Piano extends Instrumento_Pentagrama
{
	@Override
	protected String darNombre()
	{
		return "Piano";
	}
	
	
	@Override
	protected String LeerNotas()
	{
		String Notas=" � INTERPRETACION: ";
		for(int i=0;i<POSICION;i++)
		{
			switch(PENTAGRAMA[i])
			{
				case DO:
					Notas+="DOo ";
					break;
				case RE:
					Notas+="REe ";
					break;
				case MI:
					Notas+="MIi ";
					break;
				case FA:
					Notas+="FAa ";
					break;
				case SOL:
					Notas+="SOl ";
					break;
				case LA:
					Notas+="LAa ";
					break;
				case SI:
					Notas+="SIi ";
					break;
				case DOs:
					Notas+="+DOo ";
					break;
				case REs:
					Notas+="+REe ";
					break;
				case MIs:
					Notas+="+MIi ";
					break;
				case FAs:
					Notas+="+FAa ";
					break;
				case SOLs:
					Notas+="+SOl ";
					break;
				case LAs:
					Notas+="+LAa ";
					break;
				case SIs:
					Notas+="+SIi ";
					break;
			}
		}
		return Notas;
	}
}


////////////////////////////////////////////////////////////////