////////////////////////////////////////////////////////////////


package c20_Instrumentos_Musicales;


////////////////////////////////////////////////////////////////


class MAIN
{
	public static void main(String[] args)
	{
		////////////////////////////////////////////////////////
		
		
		Orquesta ORQUESTA=new Orquesta();
		ORQUESTA.Margen();
		ORQUESTA.NuevoInstrumento();
		ORQUESTA.Margen();
		//ORQUESTA.NuevoInstrumento();
		//ORQUESTA.Margen();
		
		
		////////////////////////////////////////////////////////


		
		
		////////////////////////////////////////////////////////
		
		
		
		////////////////////////////////////////////////////////
		
		
		/*
		System.out.println("   @    ");
		System.out.println("  /|    ");
		System.out.println("  ||    ");
		System.out.println("  ||    ");
		System.out.println(" |@@L   ");
		System.out.println(" L@@S|_/");
		System.out.println(" L@@/   ");
		System.out.println("   |    ");
		System.out.println("  _|    ");
		*/
		
		
		/*
		System.out.println();
		System.out.println("--------------------------------------------------");
		System.out.println("oooooooooooooooooooooooooooooooooooooooooooooooooo");
		System.out.println("         �                    o             �     ");
		System.out.println();
		*/
		
		////////////////////////////////////////////////////////
	}
}


////////////////////////////////////////////////////////////////