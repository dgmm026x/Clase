////////////////////////////////////////////////////////////////


package c20_Instrumentos_Musicales;


import java.util.Random;


////////////////////////////////////////////////////////////////


class Orquesta
{
	Random rd=new Random();
	protected int ORQUESTA[];
	protected int PARTITURA[];
	private int LONG;
	private int LONGPARTITURA;
	protected int POSICION;
	
	
	Orquesta()
	{
		this.LONG=50;
		this.POSICION=0;
		this.ORQUESTA=new int[LONG];
		this.LONGPARTITURA=11;
		this.PARTITURA=new int[LONGPARTITURA];
	}
	
	
	protected void Margen()
	{
		System.out.println();
		System.out.println();
		System.out.println("_________________________________________________________________");
		System.out.println("/////////////////////////////////////////////////////////////////");
	}
	
	
	protected void NuevoInstrumento()
	{
		if(POSICION==LONG-1)
		{
			System.out.println(" ---L�mite de instrumentos alcanzado---");
		}
		
		
		else
		{
			System.out.println();
			System.out.println();
			ORQUESTA[POSICION]=rd.nextInt(2);
			System.out.println(ORQUESTA[POSICION]);
			
			
			switch(ORQUESTA[POSICION])
			{
				case 0:
					Instrumento_Pentagrama INSTRUMENTO0=new Campana();
					for(int i=0;i<LONGPARTITURA;i++)
					{
						PARTITURA[i]=rd.nextInt(13);
						switch(PARTITURA[i])
						{
							case 0:
								INSTRUMENTO0.NuevaNota(AlturaNota.DO);
								break;
							case 1:
								INSTRUMENTO0.NuevaNota(AlturaNota.RE);
								break;
							case 2:
								INSTRUMENTO0.NuevaNota(AlturaNota.MI);
								break;
							case 3:
								INSTRUMENTO0.NuevaNota(AlturaNota.FA);
								break;
							case 4:
								INSTRUMENTO0.NuevaNota(AlturaNota.SOL);
								break;
							case 5:
								INSTRUMENTO0.NuevaNota(AlturaNota.LA);
								break;
							case 6:
								INSTRUMENTO0.NuevaNota(AlturaNota.SI);
								break;
							case 7:
								INSTRUMENTO0.NuevaNota(AlturaNota.DOs);
								break;
							case 8:
								INSTRUMENTO0.NuevaNota(AlturaNota.REs);
								break;
							case 9:
								INSTRUMENTO0.NuevaNota(AlturaNota.MIs);
								break;
							case 10:
								INSTRUMENTO0.NuevaNota(AlturaNota.FAs);
								break;
							case 11:
								INSTRUMENTO0.NuevaNota(AlturaNota.SOLs);
								break;
							case 12:
								INSTRUMENTO0.NuevaNota(AlturaNota.LAs);
								break;
							case 13:
								INSTRUMENTO0.NuevaNota(AlturaNota.SIs);
								break;
						}
					}
					System.out.println(" � INSTRUMENTO: "+INSTRUMENTO0.darNombre());
					INSTRUMENTO0.MostrarPentagrama();
					System.out.println(INSTRUMENTO0.LeerNotas());
					break;
				
				
				case 1:
					Instrumento_Pentagrama INSTRUMENTO1=new Piano();
					for(int i=0;i<LONGPARTITURA;i++)
					{
						PARTITURA[i]=rd.nextInt(13);
						switch(PARTITURA[i])
						{
							case 0:
								INSTRUMENTO1.NuevaNota(AlturaNota.DO);
								break;
							case 1:
								INSTRUMENTO1.NuevaNota(AlturaNota.RE);
								break;
							case 2:
								INSTRUMENTO1.NuevaNota(AlturaNota.MI);
								break;
							case 3:
								INSTRUMENTO1.NuevaNota(AlturaNota.FA);
								break;
							case 4:
								INSTRUMENTO1.NuevaNota(AlturaNota.SOL);
								break;
							case 5:
								INSTRUMENTO1.NuevaNota(AlturaNota.LA);
								break;
							case 6:
								INSTRUMENTO1.NuevaNota(AlturaNota.SI);
								break;
							case 7:
								INSTRUMENTO1.NuevaNota(AlturaNota.DOs);
								break;
							case 8:
								INSTRUMENTO1.NuevaNota(AlturaNota.REs);
								break;
							case 9:
								INSTRUMENTO1.NuevaNota(AlturaNota.MIs);
								break;
							case 10:
								INSTRUMENTO1.NuevaNota(AlturaNota.FAs);
								break;
							case 11:
								INSTRUMENTO1.NuevaNota(AlturaNota.SOLs);
								break;
							case 12:
								INSTRUMENTO1.NuevaNota(AlturaNota.LAs);
								break;
							case 13:
								INSTRUMENTO1.NuevaNota(AlturaNota.SIs);
								break;
						}
					}
					System.out.println(" � INSTRUMENTO: "+INSTRUMENTO1.darNombre());
					INSTRUMENTO1.MostrarPentagrama();
					System.out.println(INSTRUMENTO1.LeerNotas());
					break;
			}
			POSICION++;
		}
	}
}


////////////////////////////////////////////////////////////////