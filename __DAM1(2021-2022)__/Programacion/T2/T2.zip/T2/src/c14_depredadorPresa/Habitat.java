

package c14_depredadorPresa;


public enum Habitat
{
	Selva, Bosque;
}