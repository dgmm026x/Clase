package c01_animal;

public class Datos
{
	Animal Gato=new Animal();
	//Gato.setNombre("Gato");
	//Gato.setTipo("Felino");
}