package c01_animal;


public class Animal
{
	private String tipo;
	private String nombre;
	
	
	public void setNombre(String nombre){this.nombre=nombre;}
	public String getNombre(){return nombre;}
	
	
	public void setTipo(String tipo){this.tipo=tipo;}
	public String getTipo(){return tipo;}
}