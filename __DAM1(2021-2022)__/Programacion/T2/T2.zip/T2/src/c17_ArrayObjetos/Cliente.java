//////////////////////////////////////////////////////////////


package c17_ArrayObjetos;


//////////////////////////////////////////////////////////////


class Cliente
{
	protected String nombre;
	protected String dni;
	
	
	Cliente(String nombre,String dni)
	{
		this.nombre=nombre;
		this.dni=dni;
	}
	
	
	protected void setNombre(String nombre){this.nombre=nombre;}
	protected String getNombre(){return nombre;}
	
	protected void setDni(String dni){this.dni=dni;}
	protected String getDni(){return dni;}
	
	
	@Override
	public String toString()
	{
		return "Cliente: "+nombre+", "+dni+"...";
	}
}


//////////////////////////////////////////////////////////////