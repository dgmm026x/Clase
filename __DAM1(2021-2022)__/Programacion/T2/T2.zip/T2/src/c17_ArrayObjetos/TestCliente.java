//////////////////////////////////////////////////////////////


package c17_ArrayObjetos;


//////////////////////////////////////////////////////////////


public class TestCliente
{
	public static void main(String[] args)
	{
		Cliente c1=new Cliente("Mauricio","52516463G");
		Cliente c2=new Cliente("Americio","35246794H");

		System.out.println();
		System.out.println();
		System.out.println(" Objeto:");
		System.out.println();
		System.out.println("  "+c1);
		System.out.println("  "+c2);
		System.out.println();
		System.out.println();
		System.out.println(" Array:");
		System.out.println();
		
		Cliente arr[]=new Cliente[5];
		arr[0]=c1;
		arr[1]=c2;
		
		for (int i=0; i<arr.length; i++)
		{
			System.out.println("  "+arr[i]);
		}
	}
}


//////////////////////////////////////////////////////////////