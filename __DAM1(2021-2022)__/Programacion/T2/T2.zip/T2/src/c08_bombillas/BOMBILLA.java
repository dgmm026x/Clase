package c08_bombillas;

public class BOMBILLA
{
	public boolean SALON;
	//public boolean EST_SALON;
	public boolean COCINA;
	//public boolean EST_COCINA;
	public boolean ENTRADA;
	//public boolean EST_ENTRADA;
	public boolean PASILLO;
	//public boolean EST_PASILLO;
	public boolean HABITACION;
	//public boolean EST_HABITACION;
	public boolean BANNO;
	//public boolean EST_BANNO;
	public boolean TOTAL;
	
	
	public void setSALON(boolean SALON){this.SALON=SALON;}
	public boolean getSALON(){return SALON;}
	
	public void setCOCINA(boolean COCINA){this.COCINA=COCINA;}
	public boolean getCOCINA(){return COCINA;}
	
	public void setENTRADA(boolean ENTRADA){this.ENTRADA=ENTRADA;}
	public boolean getENTRADA(){return ENTRADA;}
	
	public void setPASILLO(boolean PASILLO){this.PASILLO=PASILLO;}
	public boolean getPASILLO(){return PASILLO;}
	
	public void setHABITACION(boolean HABITACION){this.HABITACION=HABITACION;}
	public boolean getHABITACION(){return HABITACION;}
	
	public void setBANNO(boolean BANNO){this.BANNO=BANNO;}
	public boolean getBANNO(){return BANNO;}
	
	public void setTOTAL(boolean TOTAL){this.TOTAL=TOTAL;}
	public boolean getTOTAL(){return TOTAL;}
}