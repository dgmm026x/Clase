/////////////////////////////////////////////////////////////////


package c22_PesoCompra;


/////////////////////////////////////////////////////////////////


class Bascula
{
	protected Producto Bascula_Listado_Productos[];
	protected int Bascula_Posicion;
	
	
	Bascula()
	{
		this.Bascula_Listado_Productos=new Producto[5];
		this.Bascula_Posicion=0;
	}
	
	
	protected void A�adir_Producto(String Producto_Nombre,double Producto_Precio,double Producto_Peso)
	{
		Producto PRODUCTO=new Producto(Producto_Nombre,Producto_Precio,Producto_Peso);
		Bascula_Listado_Productos[Bascula_Posicion]=PRODUCTO;
		Bascula_Posicion++;
	}
	
	
	protected void Eliminar_Ultimo_Producto()
	{
		Bascula_Listado_Productos[Bascula_Posicion]=null;
		Bascula_Posicion--;
	}
	
	
	protected String Peso_Total_Productos()
	{
		double Peso_Total=0;
		for (int i=0;i<Bascula_Posicion;i++)
		{
			Peso_Total+=Bascula_Listado_Productos[i].getProducto_Peso();
		}
		return " � Peso total de productos: hay "+Peso_Total+" Kg...";
	}
	
	
	protected String Precio_Total_Productos()
	{
		double Precio_Total=0;
		for (int i=0;i<Bascula_Posicion;i++)
		{
			Precio_Total+=Bascula_Listado_Productos[i].getProducto_Precio();
		}
		return " � Precio total de productos: es "+Precio_Total+" �...";
	}
	
	
	protected String Numero_Total_Productos()
	{
		return " � Cantidad de productos: hay "+Bascula_Posicion+" productos...";
	}
	
	
	protected String Lista_Total_Productos()
	{
		String Lista_Total="  � Lista de productos:\n";
		for (int i=0;i<Bascula_Posicion;i++)
		{
			Lista_Total+="   � Producto n�"+(i+1);
			Lista_Total+=Bascula_Listado_Productos[i].toString();
		}
		return Lista_Total;
	}
}


/////////////////////////////////////////////////////////////////