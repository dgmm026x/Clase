/////////////////////////////////////////////////////////////////


package c22_PesoCompra;


/////////////////////////////////////////////////////////////////


class Principal
{
	public static void main(String[] args)
	{
		Bascula BASCULA=new Bascula();
		
		BASCULA.A�adir_Producto("Mandarinas", 5, 0.5);
		BASCULA.A�adir_Producto("Chocolate", 1.5, 0.1);
		BASCULA.A�adir_Producto("Miel", 5, 0.3);
		
		
		
		System.out.println();
		System.out.println();
		System.out.println(BASCULA.Lista_Total_Productos());
		System.out.println();
		System.out.println();
		
		
		BASCULA.Eliminar_Ultimo_Producto();
		
		
		System.out.println();
		System.out.println();
		System.out.println(BASCULA.Lista_Total_Productos());
		System.out.println();
		System.out.println();
		
		
		System.out.println(BASCULA.Numero_Total_Productos());
		System.out.println();
		System.out.println(BASCULA.Precio_Total_Productos());
		System.out.println();
		System.out.println(BASCULA.Peso_Total_Productos());
	}
}


/////////////////////////////////////////////////////////////////