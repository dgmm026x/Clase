/////////////////////////////////////////////////////////////////


package c22_PesoCompra;


/////////////////////////////////////////////////////////////////


class Producto
{
	protected String Producto_Nombre;
	protected double Producto_Precio;
	protected double Producto_Peso;
	
	
	Producto(String Producto_Nombre,double Producto_Precio,double Producto_Peso)
	{
		this.Producto_Nombre=Producto_Nombre;
		this.Producto_Precio=Producto_Precio;
		this.Producto_Peso=Producto_Peso;
	}
	
	
	protected void setProducto_Nombre(String Producto_Nombre){this.Producto_Nombre=Producto_Nombre;}
	protected String getProducto_Nombre(){return Producto_Nombre;}
	
	
	protected void setProducto_Precio(double Producto_Precio){this.Producto_Precio=Producto_Precio;}
	protected double getProducto_Precio(){return Producto_Precio;}
	
	
	protected void setProducto_Peso(double Producto_Peso){this.Producto_Peso=Producto_Peso;}
	protected double getProducto_Peso(){return Producto_Peso;}
	
	
	protected String Ver_Prodcuto()
	{
		return Producto_Nombre+", "+Producto_Precio+"�, ("+Producto_Peso+")";
	}
}


/////////////////////////////////////////////////////////////////