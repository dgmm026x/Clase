////////////////////////////////////////////////////////////


package c18_Biblioteca;


////////////////////////////////////////////////////////////


class Ejemplar
{
	private String titulo;
	private String autor;
	String isbn;
	
	
	Ejemplar(String titulo,String autor,String isbn)
	{
		super();
		setTitulo(titulo);
		setAutor(autor);
		setIsbn(isbn);
	}
	
	
	void setTitulo(String titulo){this.titulo=titulo;}
	String getTitulo(){return titulo;}
	
	void setAutor(String autor){this.autor=autor;}
	String getAutor(){return autor;}
	
	void setIsbn(String isbn){this.isbn=isbn;}
	String getIsbn(){return isbn;}
	
	
	String descripcion()
	{
		return "LIBRO: '"+titulo+"', por "+autor+", tipo:"/*+tipo*/+" ("+isbn+")";
	}
}


////////////////////////////////////////////////////////////