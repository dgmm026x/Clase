////////////////////////////////////////////////////////////


package c18_Biblioteca;


////////////////////////////////////////////////////////////


public class TestBiblioteca
{
	public static void main(String[] args)
	{
		Biblioteca b1=new Biblioteca(100);
		
		b1.agregarEjemplar("unu","Nicol","20211231");
		b1.agregarEjemplar("...","Nicol","20220101");
		b1.agregarEjemplar(":v","Nicol","20220305");
		b1.agregarEjemplar("que","Nicol","20220308");
		
		
		System.out.println(b1.inventario());
	}
}


////////////////////////////////////////////////////////////