////////////////////////////////////////////////////////////


package c18_Biblioteca;


////////////////////////////////////////////////////////////


class Biblioteca
{
	private Ejemplar arrayEjemplares[];
	private int Longitud;
	
	
	Biblioteca(int Longitud)
	{
		this.arrayEjemplares=new Ejemplar[Longitud];
		this.Longitud=0;
	}
	
	
	protected void agregarEjemplar(String titulo,String autor,String isbn)
	{
		Ejemplar l1=new Ejemplar(titulo,autor,isbn);
		this.arrayEjemplares[Longitud]=l1;
		Longitud++;
	}
	
	protected String inventario()
	{
		String Datos="";
		for(int i=0;i<Longitud;i++)
			Datos+=" (Posicion: "+i+"): "+this.arrayEjemplares[i].descripcion();
		return Datos;
	}
	
	
//	protected void reorganizarInventario()
//	{
//		int Longitud=0;
//		for (int i=0;i<arrayEjemplares.length;i++)
//		{
//			if(this.arrayEjemplares[i].getTitulo()==titulo)
//			{
//				Longitud=i;
//				break;
//			}
//			this.arrayEjemplares[Longitud]=this.arrayEjemplares[this.numeroLibros-1];
//			this.numeroLibros--;
//		}
//	}
}


////////////////////////////////////////////////////////////