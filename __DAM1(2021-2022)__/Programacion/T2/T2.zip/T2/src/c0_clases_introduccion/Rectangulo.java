package c0_clases_introduccion;


public class Rectangulo
{
	public double ordenadaA=1;
	public double abcisaA=1;
	
	public double ordenadaB=1.004;
	public double abcisaB=1.002;
}