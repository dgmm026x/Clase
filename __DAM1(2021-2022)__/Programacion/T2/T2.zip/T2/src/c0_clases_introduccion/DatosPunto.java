package c0_clases_introduccion;

public class DatosPunto
{
	public static void main(String[] args)
	{
		//public Punto1(2,5);
	
	}
}
