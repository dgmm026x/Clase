package c10_persona_y_fecha;

public class Persona
{
	private String NOMBRE;
	private Fecha FECHA;
}