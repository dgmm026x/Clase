package c10_persona_y_fecha;

public class Accion_10
{
	public static void main(String[] args)
	{
	}
}