////////////////////////////////////////////////////////////////


package c23_Wordle;


////////////////////////////////////////////////////////////////


class Wordle
{
	protected Letra[] arrayLetras;
	protected Jugador[] ranking;
	
	
	Wordle(){}
	
	
	public void iniciar()
	{
	}
	
	
	public void a�adirJugador(String Jugador)
	{
		Jugador JUGADOR=new Jugador(Jugador);
	}
	
	private void desordenar()
	{
	}
	
	
	public String comprobar(String String)
	{
		return "";
	}
}


////////////////////////////////////////////////////////////////