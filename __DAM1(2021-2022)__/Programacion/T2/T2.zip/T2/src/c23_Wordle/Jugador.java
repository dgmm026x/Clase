////////////////////////////////////////////////////////////////


package c23_Wordle;


////////////////////////////////////////////////////////////////


class Jugador
{
	protected String nombre;
	protected int puntuacion;
	
	
	Jugador(String nombre)
	{
		this.nombre=nombre;
		this.puntuacion=0;
	}
	
	
	public void setPuntuacion(int puntuacion){this.puntuacion=puntuacion;}
	public int getPuntuacion(){return puntuacion;}
	
	
	@Override
	public String toString()
	{
		return " � Jugador: "+nombre+", Puntos: "+puntuacion;
	}
}


////////////////////////////////////////////////////////////////