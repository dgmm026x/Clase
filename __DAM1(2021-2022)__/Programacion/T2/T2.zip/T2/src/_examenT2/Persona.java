/////////////////////////////////////////////////////////////////


package _examenT2;


/////////////////////////////////////////////////////////////////


abstract class Persona implements Planificador
{
	private String nombre;
	private String apellidos;
	private int edad;
	private String municipio;
	
	
	
	public Persona(String nombre,String apellidos,int edad,String municipio)
	{
		super();
		this.nombre=nombre;
		this.apellidos=apellidos;
		this.edad=edad;
		this.municipio=municipio;
	}
	
	
	
	public String getNombre()
	{return nombre;}
	
	public void setNombre(String nombre)
	{this.nombre = nombre;}
	
	public String getApellidos()
	{return apellidos;}
	
	public void setApellidos(String apellidos)
	{this.apellidos = apellidos;}
	
	public int getEdad()
	{return edad;}
	
	public void setEdad(int edad)
	{this.edad = edad;}
	
	public String getMunicipio()
	{return municipio;}
	
	public void setMunicipio(String municipio)
	{this.municipio = municipio;}
	
	
	
	protected String descripcion()
	{
		String descripcion=nombre+" "+apellidos+", "+edad+" a�os. Es de: "+municipio;
		return descripcion;
	}
	
	
	
	public String planning()
	{return null;}
}


/////////////////////////////////////////////////////////////////