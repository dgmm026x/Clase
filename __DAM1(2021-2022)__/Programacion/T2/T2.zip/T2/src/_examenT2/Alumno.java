/////////////////////////////////////////////////////////////////


package _examenT2;


/////////////////////////////////////////////////////////////////


class Alumno extends Persona 
{
	private TipoAlumno cursoAlumno;
	
	private String accionesAlumno[];
	private int longitudAcciones;
	
	
	
	Alumno(String nombre,String apellidos,int edad,String municipio,TipoAlumno cursoAlumno)
	{
		super(nombre,apellidos,edad,municipio);
		setTipoAlumno(cursoAlumno);
		
		this.longitudAcciones=1;
		this.accionesAlumno=new String[longitudAcciones];
	}
	
	
	
	public void setTipoAlumno(TipoAlumno cursoalumno){}
	
	
	
	public String planning(String dato)
	{
		for (int i=0;i<longitudAcciones;i++)
		{
			accionesAlumno[i]=dato;
		}
		
		String datoFinal="\n\n � Planning: \n";
		
		for (int i=0;i<longitudAcciones;i++)
		{
			datoFinal+="       � "+accionesAlumno[i]+"\n";
		}
		
		datoFinal+="\n\n";
		
		return datoFinal;
	}
	
	
	
	@Override
	public String planning()
	{return null;}
}


/////////////////////////////////////////////////////////////////