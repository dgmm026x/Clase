/////////////////////////////////////////////////////////////////


package _examenT2;


/////////////////////////////////////////////////////////////////


class Empleado extends Persona
{
	private TipoEmpleado tipoEmpleado;
	
	private String accionesEmpleado[];
	private int longitudAcciones;
	
	
	
	Empleado(String nombre,String apellidos,int edad,String municipio,TipoEmpleado tipoEmpleado,int numeroCuenta)
	{
		super(nombre,apellidos,edad,municipio);
		setTipoEmpleado(tipoEmpleado);
	
		this.longitudAcciones=1;
		this.accionesEmpleado=new String[longitudAcciones];
		
		CuentaCorriente CUENTA=new CuentaCorriente(numeroCuenta);
	}
	
	
	
	public void setTipoEmpleado(TipoEmpleado tipoEmpleado){}
	
	
	
	public String planning(String dato)
	{
		for (int i=0;i<longitudAcciones;i++)
		{
			accionesEmpleado[i]=dato;
		}
		
		String datoFinal="\n\n � Planning: \n";
		
		for (int i=0;i<longitudAcciones;i++)
		{
			datoFinal+="       � "+accionesEmpleado[i]+"\n";
		}
		
		datoFinal+="\n\n";
		
		return datoFinal;
	}
	
	
	
	@Override
	public String planning()
	{return null;}
}


/////////////////////////////////////////////////////////////////