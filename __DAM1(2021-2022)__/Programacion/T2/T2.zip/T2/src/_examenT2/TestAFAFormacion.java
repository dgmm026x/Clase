/////////////////////////////////////////////////////////////////


package _examenT2;


/////////////////////////////////////////////////////////////////


public class TestAFAFormacion
{

	public static void main(String[] args)
	{
		AfaFormacion AFA=new AfaFormacion();
		
		
		
		Persona ALUMNO_1=new Alumno("Nicol","unu unu",20,"Oviedo",TipoAlumno.PRIMERO);
		Persona ALUMNO_2=new Alumno("Adelin","unu unu",20,"Gijon",TipoAlumno.PRIMERO);
		Persona ALUMNO_3=new Alumno("Sophia","unu unu",20,"Gijon",TipoAlumno.PRIMERO);
		Persona ALUMNO_4=new Alumno("Florin","unu unu",20,"Oviedo",TipoAlumno.PRIMERO);
		Persona ALUMNO_5=new Alumno("Helena","unu unu",20,"Aviles",TipoAlumno.PRIMERO);
		
		AFA.insertar(ALUMNO_1);
		AFA.insertar(ALUMNO_2);
		AFA.insertar(ALUMNO_3);
		AFA.insertar(ALUMNO_4);
		AFA.insertar(ALUMNO_5);
		
		System.out.println(AFA.listinAlumnos());
		
		
		
		Persona EMPLEADO_1=new Empleado("Isabel","Pita Olaya",40,"Oviedo",TipoEmpleado.PROFESOR,4123325);
		Persona EMPLEADO_2=new Empleado("Nico","Marian Petrusor",30,"Aviles",TipoEmpleado.SECRETARIO,2352134);
		Persona EMPLEADO_3=new Empleado("Jessica","Cuevas Cuevas",41,"Gijon",TipoEmpleado.JEFA_ESTUDIOS,4524523);
		
		AFA.insertar(EMPLEADO_1);
		AFA.insertar(EMPLEADO_2);
		AFA.insertar(EMPLEADO_3);
		
		System.out.println(AFA.listinEmpleados());
	}
}


/////////////////////////////////////////////////////////////////