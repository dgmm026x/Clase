/////////////////////////////////////////////////////////////////


package _examenT2;


/////////////////////////////////////////////////////////////////


class AfaFormacion
{
	private Alumno alumnos[];
	private int numeroAlumnos;
	private Empleado empleados[];
	private int numeroEmpleados;
	
	
	
	public AfaFormacion()
	{
		System.out.println();
		System.out.println();
		System.out.println(" �� ��������AFA�������� ��");
		System.out.println();
		System.out.println();
		
		this.numeroAlumnos=0;
		this.numeroEmpleados=0;
		
		this.alumnos=new Alumno[100];
		this.empleados=new Empleado[10];
	}
	
	
	
	public void insertar(Persona p)
	{
		if(p.getClass()==Alumno.class)
		{
			alumnos[numeroAlumnos]=(Alumno)p;
			numeroAlumnos++;
		}
		
		if(p.getClass()==Empleado.class)
		{
			empleados[numeroEmpleados]=(Empleado)p;
			numeroEmpleados++;
		}
	}
	
	
	
	public String listinAlumnos()
	{
		String listin=" �� LISTADO ALUMNOS ��\n\n";
		
		for (int i=0;i<numeroAlumnos;i++)
		{
			listin+="     � "+alumnos[i].descripcion()+"\n";
		}
		
		listin+="\n\n";
		
		return listin;
	}
	
	
	
	public String listinEmpleados()
	{
		String listin=" �� LISTADO EMPLEADOS ��\n\n";
		
		for (int i=0;i<numeroEmpleados;i++)
		{
			listin+="     � "+empleados[i].descripcion()+"\n";
		}
		
		listin+="\n\n";
		
		return listin;
	}
}


/////////////////////////////////////////////////////////////////