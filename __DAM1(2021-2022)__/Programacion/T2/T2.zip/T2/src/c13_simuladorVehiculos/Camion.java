package c13_simuladorVehiculos;

class Camion extends Vehiculo
{
	protected boolean remolque;
	
	Camion(){}
	
	Camion(String matricula,boolean remolque)
	{
		super(matricula);
		this.remolque=remolque;
	}
	
	public boolean ponerRemolque(){return remolque=true;}
	public boolean quitarRemolque(){return remolque=false;}
	
	@Override
	public String toString()
	{
		if(velocidad>100)
			velocidad=100;

		return super.toString()+" Remolque: "+remolque;
	}
}