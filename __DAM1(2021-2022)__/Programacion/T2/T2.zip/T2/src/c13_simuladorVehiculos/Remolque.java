package c13_simuladorVehiculos;

class Remolque extends Camion
{
	protected int peso;
	
	Remolque(){}
	
	Remolque(int peso)
	{
		this.peso=peso;
	}
	
	protected void setPeso(int peso){this.peso=peso;}
	protected int getPeso(){return peso;}
	
	@Override
	public String toString()
	{
		return toString()+" Remolque peso: "+peso;
	}
}