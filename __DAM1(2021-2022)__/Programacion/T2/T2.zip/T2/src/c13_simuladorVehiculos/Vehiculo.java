package c13_simuladorVehiculos;

class Vehiculo
{
	protected String matricula;
	protected int velocidad;
	
	Vehiculo(){}
	
	protected void setMatricula(String matricula){this.matricula=matricula;}
	protected String getMatricula(){return matricula;}
	
	protected void setVelocidad(int velocidad){this.velocidad=velocidad;}
	protected int getVelocidad(){return velocidad;}
	
	protected int acelerar()
	{
		return velocidad+=velocidad;
	}
	
	protected int decelerar()
	{
		velocidad-=velocidad;
		if(velocidad<-10)
			velocidad=-10;
		return velocidad;
	}
}