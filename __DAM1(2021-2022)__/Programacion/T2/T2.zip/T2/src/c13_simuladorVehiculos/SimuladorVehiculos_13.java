package c13_simuladorVehiculos;

public class SimuladorVehiculos_13
{
	public static void main(String[] args)
	{
		Vehiculo coche=new Coche("3782_DSH",37,3);
		Vehiculo camion=new Camion("6335_JWD",25);
		
		System.out.println();
		System.out.println("Coche velocidad inicial:");
		System.out.println(coche.velocidad());
		
		
		
	}
}