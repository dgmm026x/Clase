package c13_simuladorVehiculos;

class Coche extends Vehiculo
{
	protected int numeroPuertas;
	
	Coche(){}
	
	Coche(String matricula,int numeroPuertas)
	{
		super(matricula);
		this.numeroPuertas=numeroPuertas;
	}
	
	protected void setNumeroPuertas(int numeroPuertas){this.numeroPuertas=numeroPuertas;}
	protected int getNumeroPuertas(){return numeroPuertas;}
	
	@Override
	public String toString()
	{
		return super.toString()+" Coche: num. puertas: "+numeroPuertas;
	}
}