package t1;
public class pC�digoSeguridad
{
	public static int cero(int valor0)
	{
		for (valor0=0;valor0<=9; valor0++);
		{
			return valor0;
		}
	}
	public static void main(String[] args)
	{
		int valor0=0;
		int valor1=0;
		int valor2=0;
		int valor3=0;
		cero((int)valor0);
		System.out.println(valor3+"-"+valor2+"-"+valor1+"-"+valor0);
	}
}