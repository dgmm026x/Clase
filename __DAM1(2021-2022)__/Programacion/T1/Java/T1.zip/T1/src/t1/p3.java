package t1;
public class p3
{
	public static void main(String[] args)
	{
		short x=7;
		int y=5;
		float f1=13.5f;
		float f2=8f;
		
		System.out.println("El valor de X es "+x+" y de Y es "+y+".");
		System.out.println("Su suma es: "+(x+y));
		System.out.printf("Divisi�n de ","X/Y es: ",(x/y));
		System.out.println((x%y));
		//System.out.printf(f1,f2);
		System.out.println((f1/f2));
	}
}
