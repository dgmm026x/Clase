/////////////////////////////////////////////////////////////////



import java.util.*;
import java.sql.*;



/////////////////////////////////////////////////////////////////



public class AfaFormacion {
	
	private Connection conexion;
	
	
	
	public AfaFormacion() {
		
		try {
			
			System.out.println("   [CONECTANDO CON BBDD...]");
			this.conexion = DriverManager.getConnection("jdbc:mysql://localhost/materialafaformacion", "root", "");
			System.out.println("   [CONEXION COMPLETADA   ]");
			System.out.println();
			System.out.println();
		}
		
		catch (SQLException e) {
		}
	}
	
	
	
	
	
	
	public void alta(int nuevaReferencia, String nuevaDescripcion, String nuevaUbicacion) {
		
		try {
			
			System.out.println("   [AGREGANDO NUEVO MATERIAL...      ]");
			
			String sentenciaSql = "INSERT INTO material (referencia, descripcion, ubicacion) VALUES (?,?,?)";
			
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaSql);
			
			sentencia.setInt(1, nuevaReferencia);
			sentencia.setString(2, nuevaDescripcion);
			sentencia.setString(3, nuevaUbicacion);
			
			
			
			sentencia.execute();
			
			System.out.println("   [MATERIAL NUEVO AGREGADO CON EXITO]");
		}
		
		catch(Exception e) {
			
			System.err.println(" � ERROR AGREGANDO NUEVO MATERIAL");
			System.out.println();
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	public void baja(int referenciaExistente) {
		
		try {
			
			System.out.println("   [ELIMINANDO MATERIAL...      ]");
			
			String sentenciaSql = "DELETE FROM material WHERE referencia = ?";
			
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaSql);
			
			sentencia.setInt(1, referenciaExistente);
			
			
			
			sentencia.execute();
			
			System.out.println("   [MATERIAL ELIMINADO CON EXITO]");
		}
		
		catch(Exception e) {
			
			System.err.println(" � ERROR ELIMINANDO MATERIAL");
			System.out.println();
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	public void actualizar(int referenciaExistente, String nuevaUbicacion) {
		
		try {
			
			System.out.println("   [ACTUALIZANDO UBICACION DEL MATERIAL...]");
			
			String sentenciaSql = "UPDATE material SET ubicacion = ? WHERE referencia = ?";
			
			PreparedStatement sentencia = conexion.prepareStatement(sentenciaSql);
			
			sentencia.setString(1, nuevaUbicacion);
			sentencia.setInt(2, referenciaExistente);
			
			
			
			sentencia.execute();
			
			System.out.println("   [UBICACION ACTUALIZADA CON EXITO       ]");
		}
		
		catch(SQLException e) {
			
			System.err.println(" � ERROR ACTUALIZANDO UBICACION");
			System.out.println();
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	public List<Material> listado() {
		
		List<Material> listaMateriales = new ArrayList<>();
		
		try {
			
			System.out.println("   [BUSCANDO MATERIALES...]");
			
			String sentenciaSql = "SELECT * FROM material";
			
			Statement sentencia = conexion.createStatement();
			
			ResultSet resultadosQuery = sentencia.executeQuery(sentenciaSql);
			
			
			
			System.out.println();
			System.out.println(" � LISTADO DE MATERIALES:");
			System.out.println();
			
			while(resultadosQuery.next()) {
				
				int nuevaReferencia = resultadosQuery.getInt(2);
				String nuevaDescripcion = resultadosQuery.getString(3);
				String nuevaUbicacion = resultadosQuery.getString(4);
				
				Material nuevoMaterial = new Material(nuevaReferencia, nuevaDescripcion, nuevaUbicacion);
				
				listaMateriales.add(nuevoMaterial);
			}
		}
		
		catch(SQLException e) {
			
			System.err.println(" � ERROR BUSCANDO MATERIALES");
			System.out.println();
			e.printStackTrace();
			listaMateriales = null;
		}
		
		return listaMateriales;
	}
	
	
	
	
	
	
	public Set<Material> listadoOrdenado() {
		
		Set<Material> listaMateriales = new LinkedHashSet<>();
		
		try {
			
			System.out.println("   [BUSCANDO MATERIALES...]");
			
			String sentenciaSql = "SELECT * FROM material";
			
			Statement sentencia = conexion.createStatement();
			
			ResultSet resultadosQuery = sentencia.executeQuery(sentenciaSql);
			
			
			
			System.out.println();
			System.out.println(" � LISTADO DE MATERIALES:");
			System.out.println();
			
			while(resultadosQuery.next()) {
				
				int nuevaReferencia = resultadosQuery.getInt(2);
				String nuevaDescripcion = resultadosQuery.getString(3);
				String nuevaUbicacion = resultadosQuery.getString(4);
				
				Material nuevoMaterial = new Material(nuevaReferencia, nuevaDescripcion, nuevaUbicacion);
				
				listaMateriales.add(nuevoMaterial);
			}
		}
		
		catch(SQLException e) {
			
			System.err.println(" � ERROR BUSCANDO MATERIALES");
			System.out.println();
			e.printStackTrace();
			listaMateriales = null;
		}
		
		return listaMateriales;
	}
	
	
	
	
	
	
	public TreeMap<String, List<Material>> mapa() {
		
		TreeMap<String, List<Material>> mapaMateriales = new TreeMap<>();
		
		try {
			
			String sentenciaSql = "SELECT * FROM material";
			
			Statement sentencia = conexion.createStatement();
			
			ResultSet resultadosQuery = sentencia.executeQuery(sentenciaSql);
			
			
			
			while(resultadosQuery.next()) {
				
				String tipoUbicacion = resultadosQuery.getString(4);
				
				if(mapaMateriales.containsKey(tipoUbicacion) == false) {
					
					List<Material> nuevaLista = new ArrayList<>();
					
					mapaMateriales.put(tipoUbicacion, nuevaLista);
				}
			}
			
			
			sentenciaSql = "SELECT * FROM material";
			
			sentencia = conexion.createStatement();
			
			resultadosQuery = sentencia.executeQuery(sentenciaSql);
			
			while(resultadosQuery.next()) {
				
				int nuevaReferencia = resultadosQuery.getInt(2);
				String nuevaDescripcion = resultadosQuery.getString(3);
				String nuevaUbicacion = resultadosQuery.getString(4);
				
				Material nuevoMaterial = new Material(nuevaReferencia, nuevaDescripcion, nuevaUbicacion);
				
				mapaMateriales.get(nuevaUbicacion).add(nuevoMaterial);
			}
		}
		
		catch(SQLException e) {
			
			System.err.println(" � ERROR BUSCANDO MATERIALES");
			System.out.println();
			e.printStackTrace();
			mapaMateriales = null;
		}
		
		return mapaMateriales;
	}
	
	
	
	
	
	
	public void cerrarConexion() {
		
		try {
			
			conexion.close();
		}
		
		catch (Exception e) {
		}
	}
}



/////////////////////////////////////////////////////////////////