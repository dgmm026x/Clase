/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////



public class Material implements Comparable<Material> {
	
	private int id;
	private int referencia;
	private String descripcion;
	private String ubicacion;
	
	
	
	Material(int nuevaReferencia, String nuevaDescripcion, String nuevaUbicacion) {
		
		this.referencia = nuevaReferencia;
		this.descripcion = nuevaDescripcion;
		this.ubicacion = nuevaUbicacion;
	}



	public int getId() {
		
		return id;
	}
	
	public void setId(int id) {
		
		this.id = id;
	}
	
	public int getReferencia() {
		
		return referencia;
	}
	
	public void setReferencia(int referencia) {
		
		this.referencia = referencia;
	}
	
	public String getDescripcion() {
		
		return descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		
		this.descripcion = descripcion;
	}
	
	public String getUbicacion() {
		
		return ubicacion;
	}
	
	public void setUbicacion(String ubicacion) {
		
		this.ubicacion = ubicacion;
	}
	
	
	
	@Override
	public String toString() {
		
		return "    � MATERIAL\n         DESCRIPCION --> " + descripcion + "\n         REFERENCIA --> " + referencia + "\n         UBICACION --> Aula " + ubicacion;
	}



	@Override
	public int compareTo(Material o) {
		return this.descripcion.compareTo(o.getDescripcion());
	}
}



/////////////////////////////////////////////////////////////////