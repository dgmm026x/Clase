USE neptuno;
SELECT
	NombreCompañia,
	NombreContacto,
	Telefono,
	Ciudad,
	Pais
	
	FROM clientes
	WHERE CargoContacto LIKE 'Gerente%'
	
	/*Solo consigo o pais o cargo....bjhfkgsgksdf*/
	/*WHERE Pais LIKE 'Estados Unidos'*/
;