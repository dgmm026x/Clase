USE 1_bbdd_201_daniel;
DROP TABLE IF EXISTS entrenador;
CREATE TABLE IF NOT EXISTS entrenador
(
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,

	nombre VARCHAR(20),
	apellidos VARCHAR(50),
	email VARCHAR(40)
);