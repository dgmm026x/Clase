USE 1_bbdd_201_daniel;
DROP TABLE IF EXISTS partidos;
CREATE TABLE IF NOT EXISTS partidos
(
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	id_equipo_visitante INT,
	id_equipo_local INT,

	fecha DATE,
	goles_local INT,
	goles_visitante INT
);