USE 1_bbdd_201_daniel;
ALTER TABLE jugadores
	ADD FOREIGN KEY(id_equipo) REFERENCES equipos(id);


ALTER TABLE equipos
	ADD FOREIGN KEY(id_entrenador) REFERENCES entrenador(id);


ALTER TABLE partidos
	ADD FOREIGN KEY(id_equipo_visitante) REFERENCES equipos(id),
	ADD FOREIGN KEY(id_equipo_local) REFERENCES equipos(id);