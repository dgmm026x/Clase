USE 1_bbdd_201_daniel;
DROP TABLE IF EXISTS equipos;
CREATE TABLE IF NOT EXISTS equipos
(
	id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	id_entrenador INT,

	nombre VARCHAR(20),
	division CHAR(12),
	ciudad VARCHAR(25),
	estadio VARCHAR(20)
);