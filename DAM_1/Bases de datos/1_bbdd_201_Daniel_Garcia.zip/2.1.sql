USE neptuno
SELECT
	*
	FROM empleados
	WHERE FechaNacimiento BETWEEN ('1955-01-15') AND ('1960-12-31')
;